package com.example.fragmentsurfaceview_uppgift

class SkrivvUTT {

    fun utSkrifter(){
        println("hej, Hej")
    }
}
